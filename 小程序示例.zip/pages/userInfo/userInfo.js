// pages/userInfo/userInfo.js
const app = getApp();
Page({
  data: {
      userPhone : '12345',
      showModal:false
  },
  onLoad: function (objects) {

  },
  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  },
  onUnload: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
    changeName : function () {
        this.setData({
            showModal : true,
        });
    }
})
