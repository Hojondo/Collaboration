// pages/notice/notice.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    notices : [{
        avatar : '/resources/img/avatar.jpg',
        time:'12.30',
        situation :'宋扽懂 将  显示 士大夫后很快就好几个身份士大夫sd士大夫收到士大夫士大夫 交换空间和厉害 科幻电视剧和考虑 联合国hi哦规划 i和深度',
        relation :'sd sdf 的身份士大夫sd士大夫收到士大夫士大夫 交换空间和厉害 科幻电视剧和考虑 联合国hi哦规划 i和深度和 是的'
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd 大夫收到士大夫士大夫 交换空间和厉害 ds '
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd大夫收到士大夫大夫收到士大夫士大夫 交换空间和厉害 士大夫 交换空间和厉害  ds '
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd d大夫收到士大夫士大夫 交换空间和厉害 s '
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd 大夫收到士大夫收到士大夫士大夫 交换空间和厉害 大夫士大夫 交换空间和厉害 ds '
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd 大夫收到士大夫士大夫 交换空间和厉害 ds '
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd大夫收到士大夫士大夫 交换空间和厉害  ds '
    },{
        avatar : '/resources/img/avatar.jpg',
        time:'11.00',
        situation :'士大夫 进口国 收到 接受时代光华速度快了',
        relation :'fd ds '
    }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
