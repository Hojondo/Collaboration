// pages/wodeModalHis/wodeModalHis.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      notices : [{
          avator : '/resources/img/avatar.jpg',
          name:'陈坤',
          time:'12.30',
          modalLi :['轴网和标高','一层建筑'],
          content :'sd sdf 的身份士大夫sd士大夫收到士大夫士大夫 交换空间和厉害 科幻电视剧和考虑 联合国hi哦规划 i和深度和 是的'
      },{
          avator : '/resources/img/avatar.jpg',
          name:'王军宇',
          time:'11.00',
          modalLi :['轴网和标高','一层建筑','二层建筑','三层建筑'],
          content :'fd ds '
      },{
          avator : '/resources/img/avatar.jpg',
          name:'陈坤',
          time:'11.00',
          modalLi :['三层建筑'],
          content :'fd ds '
      },{
          avator : '/resources/img/avatar.jpg',
          name:'陈坤',
          time:'11.00',
          modalLi :['轴网和标高','二层建筑','三层建筑'],
          content :'fd ds '
      },{
          avator : '/resources/img/avatar.jpg',
          name:'陈坤',
          time:'11.00',
          modalLi :['轴网和标高','一层建筑','二层建筑'],
          content :'fd ds '
      },{
          avator : '/resources/img/avatar.jpg',
          name:'陈坤',
          time:'11.00',
          modalLi :['二层建筑','三层建筑'],
          content :'fd ds '
      }
      ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})
